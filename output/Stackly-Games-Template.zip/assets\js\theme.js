/* Runs in <head> to apply the saved/system theme before rendering. */
(() => {
    let saved;
    try {
        saved = localStorage.getItem("stackly-theme");
    } catch (_) {
        /* Storage may be disabled. */
    }
    const systemDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    document.documentElement.dataset.theme =
        saved === "dark" || saved === "light" ? saved : systemDark ? "dark" : "light";
})();
