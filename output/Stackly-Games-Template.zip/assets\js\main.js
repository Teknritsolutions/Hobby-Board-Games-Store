(() => {
    const { products, events } = window.Stackly;
    const page = document.body.dataset.page;
    const query = new URLSearchParams(location.search);
    if (page === "product-details" || page === "event-details") {
        const isProduct = page === "product-details";
        const items = isProduct ? products : events;
        const id = query.get("id") || items[0].id;
        const item = items.find((x) => x.id === id);
        const main = document.querySelector("main");
        if (item) {
            main.innerHTML = window.StacklyDetails[isProduct ? "products" : "events"][id];
            const title = `${item.name || item.title} — ${isProduct ? "Game" : "Event"} Details — Stackly Games`;
            document.title = title;
            const description = item.description;
            document.querySelector('meta[name="description"]').content = description;
            document.querySelector('meta[property="og:title"]').content = title;
            document.querySelector('meta[property="og:description"]').content = description;
            const canonical = document.querySelector('link[rel="canonical"]');
            canonical.href = `${canonical.href.split("?")[0]}?id=${encodeURIComponent(id)}`;
            document.querySelector('meta[property="og:url"]').content = canonical.href;
            document.querySelector('script[type="application/ld+json"]').textContent =
                JSON.stringify({
                    "@context": "https://schema.org",
                    "@type": "WebPage",
                    name: title,
                    description,
                    isAccessibleForFree: true,
                });
        } else {
            main.innerHTML = `<section class="error-page"><div class="container"><span class="eyebrow">A little off the board</span><h1>${isProduct ? "Game" : "Session"} not found.</h1><p>That link doesn’t match anything on our shelf. There’s plenty more to discover.</p><a class="btn" href="${isProduct ? "products" : "events"}.html">Explore ${isProduct ? "all games" : "game nights"} ↗</a></div></section>`;
            document.title = `${isProduct ? "Game" : "Session"} not found — Stackly Games`;
            const robots = document.createElement("meta");
            robots.name = "robots";
            robots.content = "noindex";
            document.head.append(robots);
        }
    }

    const themeButton = document.querySelector(".theme-toggle");
    const moon = '<path d="M20 14a8 8 0 0 1-10-10 9 9 0 1 0 10 10z"/>';
    const sun =
        '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>';
    const syncTheme = () => {
        const dark = document.documentElement.dataset.theme === "dark";
        themeButton.setAttribute("aria-label", `Switch to ${dark ? "light" : "dark"} theme`);
        themeButton.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" aria-hidden="true">${dark ? sun : moon}</svg>`;
        document.querySelector('meta[name="theme-color"]').content = dark ? "#111524" : "#faf8f4";
    };
    syncTheme();
    themeButton.addEventListener("click", () => {
        const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
        document.documentElement.dataset.theme = next;
        try {
            localStorage.setItem("stackly-theme", next);
        } catch (_) {
            /* Theme still works for this page. */
        }
        syncTheme();
    });
    window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", (e) => {
        let saved;
        try {
            saved = localStorage.getItem("stackly-theme");
        } catch (_) {
            /* Continue with system preference. */
        }
        if (!saved) {
            document.documentElement.dataset.theme = e.matches ? "dark" : "light";
            syncTheme();
        }
    });

    const menu = document.querySelector(".main-nav");
    const menuToggle = document.querySelector(".menu-toggle");
    const triggers = [...document.querySelectorAll(".nav-trigger")];
    function closeDropdowns(except) {
        triggers.forEach((t) => {
            if (t !== except) {
                t.setAttribute("aria-expanded", "false");
                t.parentElement.classList.remove("open");
            }
        });
    }
    function closeMenu() {
        menu.classList.remove("is-open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Open navigation");
        closeDropdowns();
    }
    menuToggle.addEventListener("click", () => {
        const open = !menu.classList.contains("is-open");
        menu.classList.toggle("is-open", open);
        menuToggle.setAttribute("aria-expanded", String(open));
        menuToggle.setAttribute("aria-label", `${open ? "Close" : "Open"} navigation`);
        if (!open) closeDropdowns();
    });
    triggers.forEach((trigger) => {
        const parent = trigger.parentElement;
        const open = () => {
            closeDropdowns(trigger);
            parent.classList.add("open");
            trigger.setAttribute("aria-expanded", "true");
        };
        trigger.addEventListener("click", (e) => {
            if (window.innerWidth >= 1200 && e.detail > 0) {
                open();
                return;
            }
            const shouldOpen = !parent.classList.contains("open");
            closeDropdowns();
            if (shouldOpen) open();
        });
        trigger.addEventListener("keydown", (e) => {
            if (e.key === "ArrowDown") {
                e.preventDefault();
                open();
                parent.querySelector(".dropdown a").focus();
            }
        });
        parent.addEventListener("pointerenter", (e) => {
            if (e.pointerType === "mouse" && window.innerWidth >= 1200) open();
        });
        parent.addEventListener("pointerleave", () => {
            if (window.innerWidth >= 1200 && !parent.contains(document.activeElement))
                closeDropdowns();
        });
        parent.addEventListener("focusout", (e) => {
            if (!parent.contains(e.relatedTarget)) closeDropdowns();
        });
    });
    document.addEventListener("click", (e) => {
        if (!e.target.closest(".nav-item")) closeDropdowns();
        if (!e.target.closest(".site-header")) closeMenu();
    });
    menu.addEventListener("click", (e) => {
        if (e.target.closest("a")) closeMenu();
    });
    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
            const expanded = triggers.find((t) => t.getAttribute("aria-expanded") === "true");
            if (expanded) {
                closeDropdowns();
                expanded.focus();
            } else if (menu.classList.contains("is-open")) {
                closeMenu();
                menuToggle.focus();
            }
        }
    });
    window.matchMedia("(min-width: 1200px)").addEventListener("change", closeMenu);

    const topButton = document.querySelector(".back-top");
    window.addEventListener(
        "scroll",
        () => {
            topButton.hidden = scrollY < 700;
        },
        { passive: true },
    );
    topButton.addEventListener("click", () => {
        window.scrollTo({
            top: 0,
            behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth",
        });
        document.querySelector(".logo").focus({ preventScroll: true });
    });

    const dialog = document.querySelector("#product-gallery");
    if (dialog) {
        document.querySelector("[data-open-gallery]").addEventListener("click", () => {
            const source = document.querySelector(".product-gallery img");
            const target = dialog.querySelector("img");
            target.src = source.src;
            target.alt = source.alt;
            dialog.showModal();
        });
        dialog
            .querySelector("[data-close-gallery]")
            .addEventListener("click", () => dialog.close());
        dialog.addEventListener("click", (e) => {
            if (e.target === dialog) dialog.close();
        });
    }
    const product = products.find((p) => p.id === query.get("product"));
    if (product && page === "contact") {
        document.querySelector("#contact-subject").value = "product";
        document.querySelector("#contact-message").value =
            `I’d like to know more about ${product.name}. `;
        document.querySelector("#bulk-product").value = product.name;
    }
})();
